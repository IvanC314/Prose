import Button from '../Home_Page/Button';
import Login from './Login';

export default function LoginPage() {
  return (
    <div>
        <Button text="Home" targetPage='../'/>
        <Login/>
    </div>
  );
}
