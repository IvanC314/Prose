import WriteHeader from "./WriteHeader";
import WriteReview from "./WriteReview";

export default function Home() {
  return (
    <div>
        <WriteHeader/>
        <WriteReview/>
    </div>
  );
}
