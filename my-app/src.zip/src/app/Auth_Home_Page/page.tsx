import Auth_Header from './Auth_Header';
import Reviews from '../Home_Page/Reviews';

export default function Home() {
    return (
        <div>
            <Auth_Header/>
            <Reviews/>
        </div>
    );
}
