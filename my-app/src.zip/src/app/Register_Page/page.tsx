import Button from '../Home_Page/Button';
import Register from './Register';

export default function RegisterPage() {
  return (
    <div>
        <Button text="Home" targetPage='../'/>
        <Register/>
    </div>
  );
}
