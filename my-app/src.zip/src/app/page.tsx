import Header from './Home_Page/Header';
import Reviews from './Home_Page/Reviews';

export default function Home() {
  return (
    <div>
      <Header/>
      <Reviews/>
    </div>
  );
}
